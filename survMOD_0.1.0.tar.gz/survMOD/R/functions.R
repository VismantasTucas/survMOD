#' Modified Score Test for k > 2 Samples
#'
#' This function calculates the modified score test statistic and p-value for k > 2 groups in survival analysis. 
#'
#' @param list_of_dfs A list of data frames, each representing a group. Each data frame must contain:
#'   - `X_ij`: Survival times.
#'   - `delta_ij`: Event indicators (1 for event, 0 for censoring).
#' @return A list containing:
#'   - `statistic`: The test statistic.
#'   - `p_value`: The p-value for the test.
#'   - `Sigma`: The covariance matrix.
#' @examples
#' # Example usage with dummy data:
#' df1 <- data.frame(X_ij = c(1, 2, 3), delta_ij = c(1, 1, 0))
#' df2 <- data.frame(X_ij = c(1, 3, 5), delta_ij = c(0, 1, 1))
#' df3 <- data.frame(X_ij = c(2, 4, 6), delta_ij = c(1, 0, 1))
#' modified_score_k(list(df1, df2, df3))
#' @export

# Function for the Modified Score Test for k > 2 samples
modified_score_k <- function(list_of_dfs) {
  # Number of groups
  k <- length(list_of_dfs)
  
  # Total number of individuals
  n <- sum(sapply(list_of_dfs, nrow))
  
  # Assign Group identifier and sort each dataframe by survival time (X_ij)
  for (i in 1:k) {
    list_of_dfs[[i]]$Group <- i
    list_of_dfs[[i]] <- arrange(list_of_dfs[[i]], X_ij)
  }
  
  # Compute Y_i for each group separately and rename the Y_i column based on group number
  for (i in 1:k) {
    n_i <- nrow(list_of_dfs[[i]])  # Number of individuals in the i-th group
    list_of_dfs[[i]]$Y_i <- seq(from = n_i, to = 1, by = -1)  # Risk set Y_i for the i-th group
    
    # Rename the Y_i column to Y_i_group number, where group number is based on the Group variable
    group_number <- list_of_dfs[[i]]$Group[1]  # Extract the group number from the Group column
    colnames(list_of_dfs[[i]])[which(colnames(list_of_dfs[[i]]) == "Y_i")] <- paste0("Y_i_", group_number)
  }
  
  # Now compute Y_i for each group relative to the other groups' survival times
  for (i in 1:k) {
    for (i_prime in 1:k) {
      if (i != i_prime) {
        sum_y_vec <- c()  # Initialize an empty vector for storing the risk set from the other group
        for (j in 1:nrow(list_of_dfs[[i]])) {
          sum_y <- sum(list_of_dfs[[i_prime]]$X_ij >= list_of_dfs[[i]]$X_ij[j])
          sum_y_vec <- append(sum_y_vec, sum_y)
        }
        # Store the risk set for the other group
        list_of_dfs[[i]][[paste0("Y_i_", i_prime)]] <- sum_y_vec
      }
    }
  }
  
  # Combine all dataframes into one after renaming Y_i and calculating cross-group risk sets
  df_combined <- do.call(rbind, list_of_dfs)
  
  # Calculate Y_overall by summing all Y_i columns for each observation
  df_combined$Y_overall <- rowSums(df_combined[, grep("^Y_i_", colnames(df_combined))])
  
  ###############
  # Lambda calculation
  ###############
  lambda_sum <- c()
  
  # Calculate lambda for each observation in df_combined
  for (j in 1:nrow(df_combined)) {
    lambdas <- c()
    
    # Loop over all individuals to sum the hazard contributions up to time X_ij[j]
    for (r in 1:nrow(df_combined)) {
      if (df_combined$X_ij[r] <= df_combined$X_ij[j]) {
        # Hazard contribution from individual r
        lambda <- df_combined$delta_ij[r] / df_combined$Y_overall[r]
        lambdas <- append(lambdas, lambda)
      }
    }
    
    # Sum the hazard contributions for all individuals up to time X_ij[j]
    lambda_sum <- append(lambda_sum, sum(lambdas))
  }
  
  # Add the lambda values to the dataframe
  df_combined$lambda <- lambda_sum
  
  # Compute K1 and K2 weights with sqrt(n)
  for (j in 1:nrow(df_combined)){
    df_combined$K1[j] <- exp(-df_combined$lambda[j]) / sqrt(n)
  }
  
  for (j in 1:nrow(df_combined)){
    df_combined$K2[j] <- (exp(-df_combined$lambda[j]) - 1) / sqrt(n)
  }
  
  
  # Now, define V vector
  V <- matrix(0, nrow = 2*(k-1), ncol = 1)
  
  for (l in 1:2) {  # Iterate over kernel functions K1 (l = 1) and K2 (l = 2)
    for (i in 1:(k-1)) {  # Iterate over groups 1 to k-1
      # Component index: (l-1)*(k-1) + i
      component = (l-1)*(k-1) + i
      
      # Use the appropriate kernel K1 or K2 depending on l
      kernel <- if (l == 1) df_combined$K1 else df_combined$K2
      
      # Dynamically reference the Y_i_<group_number> column for the current group
      Y_i_column <- paste0("Y_i_", i)
      
      # Sum1: sum over s in group i: delta_is * K_l(X_is)
      sum1 <- sum(df_combined$delta_ij[df_combined$Group == i] * kernel[df_combined$Group == i])
      
      # Sum2: sum over all rs: delta_rs * (K_l(X_rs) / Y_overall) * Y_i(rs)
      sum2 <- sum(df_combined$delta_ij * (kernel / df_combined$Y_overall) * df_combined[[Y_i_column]])
      
      # Assign to V
      V[component, 1] <- sum1 - sum2
    }
  }
  
  # Define sigma_hat matrix
  Sigma <- matrix(0, nrow = 2*(k-1), ncol = 2*(k-1))
  
  # Helper function to get (i,l) from component index
  get_i_l <- function(c, k) {
    l = ceiling(c / (k-1))  # Determine whether we're in K1 or K2 block
    i = c - (l-1)*(k-1)     # Determine the group within the block
    return(c(i, l))          # Return a vector with group and kernel function
  }
  
  for (c1 in 1:(2*(k-1))) {
    for (c2 in 1:(2*(k-1))) {
      il1 <- get_i_l(c1, k)
      il2 <- get_i_l(c2, k)
      i1 <- il1[1]
      i2 <- il2[1]
      l1 <- il1[2]
      l2 <- il2[2]
      
      delta_ll <- ifelse(i1 == i2, 1, 0)
      
      # Dynamically reference Y_i and Y_i_prime columns based on group membership
      Y_i_prime_column <- paste0("Y_i_", i2)
      Y_i_column <- paste0("Y_i_", i1)
      
      Y_i_prime <- df_combined[[Y_i_prime_column]]
      Y_i <- df_combined[[Y_i_column]]
      
      epsilon_ii_prime <- ifelse(i1 == i2, 1, 0)
      
      # Loop over rows and calculate each row's contribution
      for (r in 1:nrow(df_combined)) {
        K1 <- df_combined$K1[r]
        K2 <- df_combined$K2[r]
        delta_ij <- df_combined$delta_ij[r]
        Y_overall <- df_combined$Y_overall[r]
        
        # Case 1: Both l1 and l2 are K1 (first method)
        if (l1 == 1 && l2 == 1) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K1^2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
          
          # Case 2: l1 is K1 and l2 is K2, or l1 is K2 and l2 is K1 (second method)
        } else if ((l1 == 1 && l2 == 2) || (l1 == 2 && l2 == 1)) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K1 * K2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
          
          # Case 3: Both l1 and l2 are K2 (third method)
        } else if (l1 == 2 && l2 == 2) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K2^2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
        }
      }
    }
  }
  
  
  # Check if Sigma is singular or ill-conditioned and apply pseudo-inverse if necessary
  det_Sigma <- det(Sigma)
  
  if (det_Sigma == 0 || is.nan(det_Sigma) || det_Sigma < 1e-10) {
    warning("Covariance matrix Sigma is singular or nearly singular. Using pseudo-inverse.")
    Sigma_inv <- ginv(Sigma)  # Use generalized inverse if Sigma is singular or ill-conditioned
  } else {
    Sigma_inv <- solve(Sigma)  # Use standard inverse if Sigma is well-conditioned
  }
  
  test_statistic <- as.numeric(t(V) %*% Sigma_inv %*% V)
  p_value <- 1 - pchisq(test_statistic, df = 2*(k-1))
  
  return(list(statistic = test_statistic, p_value = p_value, Sigma = Sigma))
}


#' Modified Log-rank Test for k > 2 Samples
#'
#' This function calculates the modified log-rank test statistic and p-value for k > 2 groups in survival analysis. 
#'
#' @param list_of_dfs A list of data frames, each representing a group. Each data frame must contain:
#'   - `X_ij`: Survival times.
#'   - `delta_ij`: Event indicators (1 for event, 0 for censoring).
#' @return A list containing:
#'   - `statistic`: The test statistic.
#'   - `p_value`: The p-value for the test.
#'   - `Sigma`: The covariance matrix.
#' @examples
#' # Example usage with dummy data:
#' df1 <- data.frame(X_ij = c(1, 2, 3), delta_ij = c(1, 1, 0))
#' df2 <- data.frame(X_ij = c(1, 3, 5), delta_ij = c(0, 1, 1))
#' df3 <- data.frame(X_ij = c(2, 4, 6), delta_ij = c(1, 0, 1))
#' modified_logrank_k(list(df1, df2, df3))
#' @export


# Function for the Modified Score Test for k > 2 samples
modified_logrank_k <- function(list_of_dfs) {
  # Number of groups
  k <- length(list_of_dfs)
  
  # Total number of individuals
  n <- sum(sapply(list_of_dfs, nrow))
  
  # Assign Group identifier and sort each dataframe by survival time (X_ij)
  for (i in 1:k) {
    list_of_dfs[[i]]$Group <- i
    list_of_dfs[[i]] <- arrange(list_of_dfs[[i]], X_ij)
  }
  
  # Compute Y_i for each group separately and rename the Y_i column based on group number
  for (i in 1:k) {
    n_i <- nrow(list_of_dfs[[i]])  # Number of individuals in the i-th group
    list_of_dfs[[i]]$Y_i <- seq(from = n_i, to = 1, by = -1)  # Risk set Y_i for the i-th group
    
    # Rename the Y_i column to Y_i_groupnumber, where groupnumber is based on the Group variable
    group_number <- list_of_dfs[[i]]$Group[1]  # Extract the group number from the Group column
    colnames(list_of_dfs[[i]])[which(colnames(list_of_dfs[[i]]) == "Y_i")] <- paste0("Y_i_", group_number)
  }
  
  # Now compute Y_i for each group relative to the other groups' survival times
  for (i in 1:k) {
    for (i_prime in 1:k) {
      if (i != i_prime) {
        sum_y_vec <- c()  # Initialize an empty vector for storing the risk set from the other group
        for (j in 1:nrow(list_of_dfs[[i]])) {
          sum_y <- sum(list_of_dfs[[i_prime]]$X_ij >= list_of_dfs[[i]]$X_ij[j])
          sum_y_vec <- append(sum_y_vec, sum_y)
        }
        # Store the risk set for the other group
        list_of_dfs[[i]][[paste0("Y_i_", i_prime)]] <- sum_y_vec
      }
    }
  }
  
  # Combine all dataframes into one after renaming Y_i and calculating cross-group risk sets
  df_combined <- do.call(rbind, list_of_dfs)
  
  # Calculate Y_overall by summing all Y_i columns for each observation
  df_combined$Y_overall <- rowSums(df_combined[, grep("^Y_i_", colnames(df_combined))])
  
  ###############
  # Lambda calculation
  ###############
  lambda_sum <- c()
  
  # Calculate lambda for each observation in df_combined
  for (j in 1:nrow(df_combined)) {
    lambdas <- c()
    
    # Loop over all individuals to sum the hazard contributions up to time X_ij[j]
    for (r in 1:nrow(df_combined)) {
      if (df_combined$X_ij[r] <= df_combined$X_ij[j]) {
        # Hazard contribution from individual r
        lambda <- df_combined$delta_ij[r] / df_combined$Y_overall[r]
        lambdas <- append(lambdas, lambda)
      }
    }
    
    # Sum the hazard contributions for all individuals up to time X_ij[j]
    lambda_sum <- append(lambda_sum, sum(lambdas))
  }
  
  # Add the lambda values to the dataframe
  df_combined$lambda <- lambda_sum
  
  # Compute K1 and K2 weights with sqrt(n)
  df_combined$K1 <- 1/sqrt(n)
  
  for (j in 1:nrow(df_combined)){
    df_combined$K2[j] <- -log(1+df_combined$lambda[j])/sqrt(n)
  }
  
  # Now, define V vector
  V <- matrix(0, nrow = 2*(k-1), ncol = 1)
  
  for (l in 1:2) {  # Iterate over kernel functions K1 (l = 1) and K2 (l = 2)
    for (i in 1:(k-1)) {  # Iterate over groups 1 to k-1
      # Component index: (l-1)*(k-1) + i
      component = (l-1)*(k-1) + i
      
      # Use the appropriate kernel K1 or K2 depending on l
      kernel <- if (l == 1) df_combined$K1 else df_combined$K2
      
      # Dynamically reference the Y_i_<group_number> column for the current group
      Y_i_column <- paste0("Y_i_", i)
      
      # Sum1: sum over s in group i: delta_is * K_l(X_is)
      sum1 <- sum(df_combined$delta_ij[df_combined$Group == i] * kernel[df_combined$Group == i])
      
      # Sum2: sum over all rs: delta_rs * (K_l(X_rs) / Y_overall) * Y_i(rs)
      sum2 <- sum(df_combined$delta_ij * (kernel / df_combined$Y_overall) * df_combined[[Y_i_column]])
      
      # Assign to V
      V[component, 1] <- sum1 - sum2
    }
  }
  
  # Define sigma_hat matrix
  Sigma <- matrix(0, nrow = 2*(k-1), ncol = 2*(k-1))
  
  # Helper function to get (i,l) from component index
  get_i_l <- function(c, k) {
    l = ceiling(c / (k-1))  # Determine whether we're in K1 or K2 block
    i = c - (l-1)*(k-1)     # Determine the group within the block
    return(c(i, l))          # Return a vector with group and kernel function
  }
  
  for (c1 in 1:(2*(k-1))) {
    for (c2 in 1:(2*(k-1))) {
      il1 <- get_i_l(c1, k)
      il2 <- get_i_l(c2, k)
      i1 <- il1[1]
      i2 <- il2[1]
      l1 <- il1[2]
      l2 <- il2[2]
      
      delta_ll <- ifelse(i1 == i2, 1, 0)
      
      # Dynamically reference Y_i and Y_i_prime columns based on group membership
      Y_i_prime_column <- paste0("Y_i_", i2)
      Y_i_column <- paste0("Y_i_", i1)
      
      Y_i_prime <- df_combined[[Y_i_prime_column]]
      Y_i <- df_combined[[Y_i_column]]
      
      epsilon_ii_prime <- ifelse(i1 == i2, 1, 0)
      
      # Loop over rows and calculate each row's contribution
      for (r in 1:nrow(df_combined)) {
        K1 <- df_combined$K1[r]
        K2 <- df_combined$K2[r]
        delta_ij <- df_combined$delta_ij[r]
        Y_overall <- df_combined$Y_overall[r]
        
        # Case 1: Both l1 and l2 are K1 (first method)
        if (l1 == 1 && l2 == 1) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K1^2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
          
          # Case 2: l1 is K1 and l2 is K2, or l1 is K2 and l2 is K1 (second method)
        } else if ((l1 == 1 && l2 == 2) || (l1 == 2 && l2 == 1)) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K1 * K2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
          
          # Case 3: Both l1 and l2 are K2 (third method)
        } else if (l1 == 2 && l2 == 2) {
          adjustment <- (epsilon_ii_prime - (Y_i_prime[r] / Y_overall)) * 
            (Y_i[r] / Y_overall)
          contribution <- delta_ij * K2^2 * adjustment
          
          Sigma[c1, c2] <- Sigma[c1, c2] + contribution
        }
      }
    }
  }
  
  
  # Check if Sigma is singular or ill-conditioned and apply pseudo-inverse if necessary
  det_Sigma <- det(Sigma)
  
  if (det_Sigma == 0 || is.nan(det_Sigma) || det_Sigma < 1e-10) {
    warning("Covariance matrix Sigma is singular or nearly singular. Using pseudo-inverse.")
    Sigma_inv <- ginv(Sigma)  # Use generalized inverse if Sigma is singular or ill-conditioned
  } else {
    Sigma_inv <- solve(Sigma)  # Use standard inverse if Sigma is well-conditioned
  }
  
  test_statistic <- as.numeric(t(V) %*% Sigma_inv %*% V)
  p_value <- 1 - pchisq(test_statistic, df = 2*(k-1))
  
  return(list(statistic = test_statistic, p_value = p_value, Sigma = Sigma))
}

